from .auth_routes import auth_bp
from .booking_routes import booking_bp
from .court_routes import court_bp
from .main_routes import main_bp
from .payment_routes import payment_bp
from .voucher_routes import voucher_bp

# Collect all blueprints
all_blueprints = [auth_bp, booking_bp, court_bp, main_bp, payment_bp, voucher_bp]
